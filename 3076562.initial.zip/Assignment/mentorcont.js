document.addEventListener("DOMContentLoaded", function() {
    const cards = document.querySelectorAll('.card-container');
    cards.forEach(cardContainer => {
        cardContainer.addEventListener('mouseenter', function() {
            const card = this.querySelector('.card');
            card.classList.add('rotated');
        });

        cardContainer.addEventListener('mouseleave', function() {
            const card = this.querySelector('.card');
            card.classList.remove('rotated');
        });
    });
});
function goBack(){
    window.history.back();
}
